par(mfrow=c(2,1))

nx <- 180
ny <- 60

data <- scan('eof_mode1.out', what=list(0.,0.,0.))

xvals <- data[[1]][1:nx]
print(xvals)

yvals <- data[[2]][seq(1,nx*ny,by=nx)]

data <- data[[3]]
dim(data) <- c(nx,ny)

print(xvals)
print(yvals)
contour( xvals, yvals, data, xlab='Longitude', ylab='Latitude' )

pc <- scan('pc_mode1.out')
plot( 1:length(pc), pc, pch=19, cex=.5, type='o', xlab='year', ylab='PC' )

